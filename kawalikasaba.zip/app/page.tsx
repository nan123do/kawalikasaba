export default function Home() {
  return(
    <>
    <h1 className="text-blue-900 text-2xl">TEST</h1>
    </>
  )
}