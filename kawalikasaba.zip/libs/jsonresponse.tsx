export interface Root {
  meta: Meta
  data: any
}

export interface Meta {
  code: number
  status: string
  message: string
}