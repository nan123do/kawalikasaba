export interface Alumni {
  id: number
  nama: string
  kelas: string
  nowa: string
  status: string
  jumlah: string
  created_at: string
}