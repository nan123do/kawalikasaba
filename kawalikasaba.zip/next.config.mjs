/** @type {import('next').NextConfig} */
const nextConfig = {
  // reactStrictMode: true,
  // env: {
  //   BASE_URL: 'http://157.245.206.185',
  // },
};

export default nextConfig;
